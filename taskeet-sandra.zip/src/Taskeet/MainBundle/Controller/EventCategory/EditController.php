<?php

namespace Taskeet\MainBundle\Controller\EventCategory;

use Admingenerated\TaskeetMainBundle\BaseEventCategoryController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
