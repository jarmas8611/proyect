<?php

namespace Taskeet\MainBundle\Controller\EventCategory;

use Admingenerated\TaskeetMainBundle\BaseEventCategoryController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
