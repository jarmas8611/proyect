<?php

namespace Taskeet\MainBundle\Controller\EventCategory;

use Admingenerated\TaskeetMainBundle\BaseEventCategoryController\ListController as BaseListController;

class ListController extends BaseListController
{
}
