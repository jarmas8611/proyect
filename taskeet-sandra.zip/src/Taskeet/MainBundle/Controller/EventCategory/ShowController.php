<?php

namespace Taskeet\MainBundle\Controller\EventCategory;

use Admingenerated\TaskeetMainBundle\BaseEventCategoryController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
