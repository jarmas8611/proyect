<?php

namespace Taskeet\MainBundle\Controller\EventCategory;

use Admingenerated\TaskeetMainBundle\BaseEventCategoryController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
