<?php

namespace Taskeet\MainBundle\Controller\Media;

use Admingenerated\TaskeetMainBundle\BaseMediaController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
