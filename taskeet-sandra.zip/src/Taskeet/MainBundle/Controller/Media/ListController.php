<?php

namespace Taskeet\MainBundle\Controller\Media;

use Admingenerated\TaskeetMainBundle\BaseMediaController\ListController as BaseListController;

class ListController extends BaseListController
{
}
