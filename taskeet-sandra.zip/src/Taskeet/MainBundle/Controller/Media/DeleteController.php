<?php

namespace Taskeet\MainBundle\Controller\Media;

use Admingenerated\TaskeetMainBundle\BaseMediaController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
