<?php

namespace Taskeet\MainBundle\Controller\Media;

use Admingenerated\TaskeetMainBundle\BaseMediaController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
