<?php

namespace Taskeet\MainBundle\Controller\Media;

use Admingenerated\TaskeetMainBundle\BaseMediaController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
