<?php

namespace Taskeet\MainBundle\Controller\Group;

use Admingenerated\TaskeetMainBundle\BaseGroupController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
