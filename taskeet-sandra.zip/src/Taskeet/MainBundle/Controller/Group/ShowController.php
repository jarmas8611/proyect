<?php

namespace Taskeet\MainBundle\Controller\Group;

use Admingenerated\TaskeetMainBundle\BaseGroupController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
