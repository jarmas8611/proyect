<?php

namespace Taskeet\MainBundle\Controller\Group;

use Admingenerated\TaskeetMainBundle\BaseGroupController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
