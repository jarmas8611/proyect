<?php

namespace Taskeet\MainBundle\Controller\Group;

use Admingenerated\TaskeetMainBundle\BaseGroupController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
