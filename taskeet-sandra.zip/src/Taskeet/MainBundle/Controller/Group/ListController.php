<?php

namespace Taskeet\MainBundle\Controller\Group;

use Admingenerated\TaskeetMainBundle\BaseGroupController\ListController as BaseListController;

class ListController extends BaseListController
{
}
