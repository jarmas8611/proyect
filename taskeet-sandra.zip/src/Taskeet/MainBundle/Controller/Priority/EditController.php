<?php

namespace Taskeet\MainBundle\Controller\Priority;

use Admingenerated\TaskeetMainBundle\BasePriorityController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
