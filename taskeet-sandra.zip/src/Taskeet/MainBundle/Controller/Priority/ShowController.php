<?php

namespace Taskeet\MainBundle\Controller\Priority;

use Admingenerated\TaskeetMainBundle\BasePriorityController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
