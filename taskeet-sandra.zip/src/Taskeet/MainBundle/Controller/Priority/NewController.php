<?php

namespace Taskeet\MainBundle\Controller\Priority;

use Admingenerated\TaskeetMainBundle\BasePriorityController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
