<?php

namespace Taskeet\MainBundle\Controller\Priority;

use Admingenerated\TaskeetMainBundle\BasePriorityController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
