<?php

namespace Taskeet\MainBundle\Controller\Priority;

use Admingenerated\TaskeetMainBundle\BasePriorityController\ListController as BaseListController;

class ListController extends BaseListController
{
}
