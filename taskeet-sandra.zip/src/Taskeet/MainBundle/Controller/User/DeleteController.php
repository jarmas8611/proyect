<?php

namespace Taskeet\MainBundle\Controller\User;

use Admingenerated\TaskeetMainBundle\BaseUserController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
