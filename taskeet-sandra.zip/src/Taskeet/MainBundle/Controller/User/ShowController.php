<?php

namespace Taskeet\MainBundle\Controller\User;

use Admingenerated\TaskeetMainBundle\BaseUserController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
