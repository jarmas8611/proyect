<?php

namespace Taskeet\MainBundle\Controller\User;

use Admingenerated\TaskeetMainBundle\BaseUserController\ListController as BaseListController;

class ListController extends BaseListController
{
//    protected function processScopes($query)
//    {
//        $scopes = $this->getScopes();
//
//        $queryFilter = $this->get('admingenerator.queryfilter.doctrine');
//        $queryFilter->setQuery($query);
//
//
//
//        if (isset($scopes['group_1']) && $scopes['group_1'] == 'Todas') {
//
//        }
//
//        if (isset($scopes['group_1']) && $scopes['group_1'] == 'En mi Departamento') {
//            $queryFilter->addCollectionFilter("departments", $this->getUser()->getDepartments());
//        }
//    }
}
