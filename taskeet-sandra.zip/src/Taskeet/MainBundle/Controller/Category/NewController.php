<?php

namespace Taskeet\MainBundle\Controller\Category;

use Admingenerated\TaskeetMainBundle\BaseCategoryController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
