<?php

namespace Taskeet\MainBundle\Controller\Category;

use Admingenerated\TaskeetMainBundle\BaseCategoryController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
