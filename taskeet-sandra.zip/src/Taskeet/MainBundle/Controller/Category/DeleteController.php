<?php

namespace Taskeet\MainBundle\Controller\Category;

use Admingenerated\TaskeetMainBundle\BaseCategoryController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
