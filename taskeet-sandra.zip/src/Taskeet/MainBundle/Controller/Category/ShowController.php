<?php

namespace Taskeet\MainBundle\Controller\Category;

use Admingenerated\TaskeetMainBundle\BaseCategoryController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
