<?php

namespace Taskeet\MainBundle\Controller\Category;

use Admingenerated\TaskeetMainBundle\BaseCategoryController\ListController as BaseListController;

class ListController extends BaseListController
{
}
