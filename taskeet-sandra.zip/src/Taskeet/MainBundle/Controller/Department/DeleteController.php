<?php

namespace Taskeet\MainBundle\Controller\Department;

use Admingenerated\TaskeetMainBundle\BaseDepartmentController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
