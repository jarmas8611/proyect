<?php

namespace Taskeet\MainBundle\Controller\Department;

use Admingenerated\TaskeetMainBundle\BaseDepartmentController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
