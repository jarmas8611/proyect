<?php

namespace Taskeet\MainBundle\Controller\Event;

use Admingenerated\TaskeetMainBundle\BaseEventController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
