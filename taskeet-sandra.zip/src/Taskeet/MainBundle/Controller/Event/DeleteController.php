<?php

namespace Taskeet\MainBundle\Controller\Event;

use Admingenerated\TaskeetMainBundle\BaseEventController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
