<?php

namespace Taskeet\MainBundle\Controller\Project;

use Admingenerated\TaskeetMainBundle\BaseProjectController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
