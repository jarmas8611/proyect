<?php

namespace Taskeet\MainBundle\Controller\Status;

use Admingenerated\TaskeetMainBundle\BaseStatusController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
