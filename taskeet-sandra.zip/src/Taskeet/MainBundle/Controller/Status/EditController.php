<?php

namespace Taskeet\MainBundle\Controller\Status;

use Admingenerated\TaskeetMainBundle\BaseStatusController\EditController as BaseEditController;

class EditController extends BaseEditController
{
}
