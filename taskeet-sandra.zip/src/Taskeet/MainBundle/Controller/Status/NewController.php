<?php

namespace Taskeet\MainBundle\Controller\Status;

use Admingenerated\TaskeetMainBundle\BaseStatusController\NewController as BaseNewController;

class NewController extends BaseNewController
{
}
