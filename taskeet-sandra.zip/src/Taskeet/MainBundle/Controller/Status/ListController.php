<?php

namespace Taskeet\MainBundle\Controller\Status;

use Admingenerated\TaskeetMainBundle\BaseStatusController\ListController as BaseListController;

class ListController extends BaseListController
{
}
