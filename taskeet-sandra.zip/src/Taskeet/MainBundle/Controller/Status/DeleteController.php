<?php

namespace Taskeet\MainBundle\Controller\Status;

use Admingenerated\TaskeetMainBundle\BaseStatusController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
