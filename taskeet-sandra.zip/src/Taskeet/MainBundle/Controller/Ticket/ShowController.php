<?php

namespace Taskeet\MainBundle\Controller\Ticket;

use Admingenerated\TaskeetMainBundle\BaseTicketController\ShowController as BaseShowController;

class ShowController extends BaseShowController
{
}
