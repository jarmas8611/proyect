<?php

namespace Taskeet\MainBundle\Controller\Ticket;

use Admingenerated\TaskeetMainBundle\BaseTicketController\DeleteController as BaseDeleteController;

class DeleteController extends BaseDeleteController
{
}
