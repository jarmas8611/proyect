<?php

namespace Taskeet\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TaskeetMainBundle extends Bundle
{
}
