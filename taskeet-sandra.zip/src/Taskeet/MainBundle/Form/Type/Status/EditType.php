<?php

namespace Taskeet\MainBundle\Form\Type\Status;

use Admingenerated\TaskeetMainBundle\Form\BaseStatusType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
