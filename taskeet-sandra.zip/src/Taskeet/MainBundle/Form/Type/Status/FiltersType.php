<?php

namespace Taskeet\MainBundle\Form\Type\Status;

use Admingenerated\TaskeetMainBundle\Form\BaseStatusType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
