<?php

namespace Taskeet\MainBundle\Form\Type\Status;

use Admingenerated\TaskeetMainBundle\Form\BaseStatusType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
