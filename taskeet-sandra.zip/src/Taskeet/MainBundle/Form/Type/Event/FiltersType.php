<?php

namespace Taskeet\MainBundle\Form\Type\Event;

use Admingenerated\TaskeetMainBundle\Form\BaseEventType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
