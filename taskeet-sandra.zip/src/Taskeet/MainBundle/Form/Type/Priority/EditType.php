<?php

namespace Taskeet\MainBundle\Form\Type\Priority;

use Admingenerated\TaskeetMainBundle\Form\BasePriorityType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
