<?php

namespace Taskeet\MainBundle\Form\Type\Priority;

use Admingenerated\TaskeetMainBundle\Form\BasePriorityType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
