<?php

namespace Taskeet\MainBundle\Form\Type\Priority;

use Admingenerated\TaskeetMainBundle\Form\BasePriorityType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
