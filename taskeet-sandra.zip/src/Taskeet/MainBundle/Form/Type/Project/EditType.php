<?php

namespace Taskeet\MainBundle\Form\Type\Project;

use Admingenerated\TaskeetMainBundle\Form\BaseProjectType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
