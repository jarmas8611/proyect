<?php

namespace Taskeet\MainBundle\Form\Type\Project;

use Admingenerated\TaskeetMainBundle\Form\BaseProjectType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
