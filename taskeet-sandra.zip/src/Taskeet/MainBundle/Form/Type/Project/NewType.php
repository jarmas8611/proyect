<?php

namespace Taskeet\MainBundle\Form\Type\Project;

use Admingenerated\TaskeetMainBundle\Form\BaseProjectType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
