<?php

namespace Taskeet\MainBundle\Form\Type\Media;

use Admingenerated\TaskeetMainBundle\Form\BaseMediaType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
