<?php

namespace Taskeet\MainBundle\Form\Type\Media;

use Admingenerated\TaskeetMainBundle\Form\BaseMediaType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
