<?php

namespace Taskeet\MainBundle\Form\Type\Media;

use Admingenerated\TaskeetMainBundle\Form\BaseMediaType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
