<?php

namespace Taskeet\MainBundle\Form\Type\EventCategory;

use Admingenerated\TaskeetMainBundle\Form\BaseEventCategoryType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
