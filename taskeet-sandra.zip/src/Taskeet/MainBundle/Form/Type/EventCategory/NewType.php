<?php

namespace Taskeet\MainBundle\Form\Type\EventCategory;

use Admingenerated\TaskeetMainBundle\Form\BaseEventCategoryType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
