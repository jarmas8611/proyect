<?php

namespace Taskeet\MainBundle\Form\Type\EventCategory;

use Admingenerated\TaskeetMainBundle\Form\BaseEventCategoryType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
