<?php

namespace Taskeet\MainBundle\Form\Type\Group;

use Admingenerated\TaskeetMainBundle\Form\BaseGroupType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
