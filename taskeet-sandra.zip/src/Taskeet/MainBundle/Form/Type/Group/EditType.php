<?php

namespace Taskeet\MainBundle\Form\Type\Group;

use Admingenerated\TaskeetMainBundle\Form\BaseGroupType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
