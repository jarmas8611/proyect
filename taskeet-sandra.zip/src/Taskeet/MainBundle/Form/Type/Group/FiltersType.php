<?php

namespace Taskeet\MainBundle\Form\Type\Group;

use Admingenerated\TaskeetMainBundle\Form\BaseGroupType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
