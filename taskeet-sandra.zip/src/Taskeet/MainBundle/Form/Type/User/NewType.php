<?php

namespace Taskeet\MainBundle\Form\Type\User;

use Admingenerated\TaskeetMainBundle\Form\BaseUserType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
