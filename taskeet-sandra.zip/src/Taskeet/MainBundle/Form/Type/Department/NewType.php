<?php

namespace Taskeet\MainBundle\Form\Type\Department;

use Admingenerated\TaskeetMainBundle\Form\BaseDepartmentType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
