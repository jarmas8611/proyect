<?php

namespace Taskeet\MainBundle\Form\Type\Department;

use Admingenerated\TaskeetMainBundle\Form\BaseDepartmentType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
