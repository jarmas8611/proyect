<?php

namespace Taskeet\MainBundle\Form\Type\Category;

use Admingenerated\TaskeetMainBundle\Form\BaseCategoryType\EditType as BaseEditType;

class EditType extends BaseEditType
{
}
