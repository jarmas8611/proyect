<?php

namespace Taskeet\MainBundle\Form\Type\Category;

use Admingenerated\TaskeetMainBundle\Form\BaseCategoryType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
