<?php

namespace Taskeet\MainBundle\Form\Type\Category;

use Admingenerated\TaskeetMainBundle\Form\BaseCategoryType\NewType as BaseNewType;

class NewType extends BaseNewType
{
}
