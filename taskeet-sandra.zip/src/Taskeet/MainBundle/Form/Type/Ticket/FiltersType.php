<?php

namespace Taskeet\MainBundle\Form\Type\Ticket;

use Admingenerated\TaskeetMainBundle\Form\BaseTicketType\FiltersType as BaseFiltersType;

class FiltersType extends BaseFiltersType
{
}
