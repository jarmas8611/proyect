### Admingenerator Javascript Plugins Namespace

To avoid conflicts Admingenerator scripts have been moved to plugins.

Admingenerator plugins use `agen$` namespace prefix.

### Alphabetical list of Admingenerator plugins

* **agen$**singleUpload